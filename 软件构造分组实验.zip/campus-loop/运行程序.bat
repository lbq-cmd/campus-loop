@echo off
rem ============================================================
rem  Campus Loop - launcher (iteration 2, console demo)
rem  Works both in the source tree (target\) and in the
rem  distributed package (build\).
rem ============================================================
chcp 65001 >nul
cd /d "%~dp0"
title Campus Loop - Campus Resource Circulation System

set "JAVA_EXE=java"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
if exist "C:\Program Files\Java\jdk-19\bin\java.exe" if not exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=C:\Program Files\Java\jdk-19\bin\java.exe"

"%JAVA_EXE%" -version >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Java not found. Please install JDK 11+ and add it to PATH.
    pause
    exit /b 1
)

set "JAR="
if exist "target\campus-loop.jar" set "JAR=target\campus-loop.jar"
if not defined JAR if exist "build\campus-loop.jar" set "JAR=build\campus-loop.jar"
if defined JAR goto run

echo Packaging the project, please wait...
set "MVN_CMD=mvn"
if exist "D:\apache-maven-3.6.3\bin\mvn.cmd" set "MVN_CMD=D:\apache-maven-3.6.3\bin\mvn.cmd"
call "%MVN_CMD%" -q clean package
if exist "target\campus-loop.jar" set "JAR=target\campus-loop.jar"
if defined JAR goto run

echo [ERROR] campus-loop.jar not found and automatic build failed.
pause
exit /b 1

:run
echo Starting... default admin account: admin / Admin123456
echo.
"%JAVA_EXE%" -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -Dstdin.encoding=UTF-8 -jar "%JAR%"
echo.
echo The program has exited. Press any key to close this window.
pause >nul
